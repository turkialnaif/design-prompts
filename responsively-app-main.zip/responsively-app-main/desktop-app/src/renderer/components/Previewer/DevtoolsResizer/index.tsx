import {Icon} from '@iconify/react';
import {DOCK_POSITION, IPC_MAIN_CHANNELS} from 'common/constants';
import {OpenDevtoolsArgs, OpenDevtoolsResult} from 'main/devtools';
import {Resizable, Size} from 're-resizable';
import {useCallback, useEffect, useRef, useState} from 'react';
import {useDispatch, useSelector} from 'react-redux';
import Button from 'renderer/components/Button';
import {
  DockPosition,
  selectDevtoolsWebviewId,
  selectDockPosition,
  setDockPosition,
  setDevtoolsClose,
} from 'renderer/store/features/devtools';
import {selectIsInspecting, setIsInspecting} from 'renderer/store/features/renderer';

type SizeValue = number | string;

interface DockConfig {
  resizeDirections: {[key: string]: boolean};
  defaultSize: {
    width: SizeValue;
    height: SizeValue;
  };
  toggle: {
    icon: string;
    position: DockPosition;
  };
}

const BottomDockConfig: DockConfig = {
  resizeDirections: {top: true},
  defaultSize: {width: '100vw', height: 500},
  toggle: {
    icon: 'mdi:dock-right',
    position: DOCK_POSITION.RIGHT,
  },
};

const RightDockConfig: DockConfig = {
  resizeDirections: {left: true},
  defaultSize: {width: 500, height: '100vh'},
  toggle: {
    icon: 'mdi:dock-bottom',
    position: DOCK_POSITION.BOTTOM,
  },
};

const DevtoolsResizer = () => {
  const dispatch = useDispatch();
  const dockPosition = useSelector(selectDockPosition);
  const webviewId = useSelector(selectDevtoolsWebviewId);
  const isInspecting = useSelector(selectIsInspecting);

  let config = BottomDockConfig;
  if (dockPosition === DOCK_POSITION.RIGHT) {
    config = RightDockConfig;
  }
  const [width, setWidth] = useState<SizeValue>(config.defaultSize.width);
  const [height, setHeight] = useState<SizeValue>(config.defaultSize.height);
  const [sizeBeforeResize, setSizeBeforeResize] = useState<Size>({
    width: 0,
    height: 0,
  });
  const contentRef = useRef<HTMLDivElement>(null);

  const sendBounds = useCallback(() => {
    if (!contentRef.current) return;
    const rect = contentRef.current.getBoundingClientRect();
    window.electron.ipcRenderer.invoke(IPC_MAIN_CHANNELS.RESIZE_DEVTOOLS, {
      bounds: {
        x: Math.round(rect.x),
        y: Math.round(rect.y),
        width: Math.round(rect.width),
        height: Math.round(rect.height),
      },
    });
  }, []);

  useEffect(() => {
    setHeight(config.defaultSize.height);
    setWidth(config.defaultSize.width);
  }, [config]);

  useEffect(() => {
    sendBounds();
  }, [width, height, dockPosition, sendBounds]);

  useEffect(() => {
    const timer = setTimeout(sendBounds, 50);
    window.addEventListener('resize', sendBounds);
    return () => {
      clearTimeout(timer);
      window.removeEventListener('resize', sendBounds);
    };
  }, [sendBounds]);

  return (
    <div
      data-testid="devtools-resizer"
      className="border-gray-300 bg-gray-100 text-gray-600 dark:border-slate-600 dark:bg-slate-800 dark:text-slate-300"
    >
      <Resizable
        className="border"
        key={dockPosition}
        size={{width, height}}
        onResizeStart={() => setSizeBeforeResize({width, height})}
        onResizeStop={() => setSizeBeforeResize({width: 0, height: 0})}
        onResize={(_, __, ___, d) => {
          setWidth((sizeBeforeResize.width as number) + d.width);
          setHeight((sizeBeforeResize.height as number) + d.height);
        }}
        enable={config.resizeDirections}
      >
        <div className="flex h-full w-full flex-col">
          <div className="flex justify-between border-b">
            <div>
              <Button
                onClick={() => dispatch(setIsInspecting(!isInspecting))}
                isActive={isInspecting}
                disableHoverEffects
              >
                <Icon icon="lucide:inspect" />
              </Button>
            </div>
            <div className="flex">
              <Button
                onClick={() => {
                  dispatch(setDockPosition(config.toggle.position));
                }}
                disableHoverEffects
              >
                <Icon icon={config.toggle.icon} />
              </Button>
              <Button
                onClick={() => {
                  window.electron.ipcRenderer.invoke(IPC_MAIN_CHANNELS.CLOSE_DEVTOOLS);
                  dispatch(setDockPosition(DOCK_POSITION.UNDOCKED));
                  dispatch(setDevtoolsClose());
                  setTimeout(() => {
                    window.electron.ipcRenderer.invoke<OpenDevtoolsArgs, OpenDevtoolsResult>(
                      IPC_MAIN_CHANNELS.OPEN_DEVTOOLS,
                      {
                        webviewId,
                        dockPosition: DOCK_POSITION.UNDOCKED,
                      }
                    );
                  });
                }}
                disableHoverEffects
              >
                <Icon icon="mdi:dock-window" />
              </Button>
              <Button
                onClick={() => {
                  window.electron.ipcRenderer.invoke(IPC_MAIN_CHANNELS.CLOSE_DEVTOOLS);
                  dispatch(setDevtoolsClose());
                }}
                disableHoverEffects
              >
                <Icon icon="ic:round-close" />
              </Button>
            </div>
          </div>
          <div ref={contentRef} className="grow" />
        </div>
      </Resizable>
    </div>
  );
};

export default DevtoolsResizer;
